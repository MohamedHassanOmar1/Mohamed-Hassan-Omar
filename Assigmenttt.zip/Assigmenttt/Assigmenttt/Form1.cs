namespace Assigmenttt
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            String Name = txtName.Text;
            String gender = "";
            double Age, ID;

            if (!double.TryParse(txtID.Text, out ID))
            {
                MessageBox.Show("Invalid ID", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtID.Clear();
                txtID.Focus();
                return;
            }

            if (!double.TryParse(txtAge.Text, out Age))
            {
                MessageBox.Show("Invalid Age", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAge.Clear();
                txtAge.Focus();
                return;
            }

            if (Age < 18)
            {
                MessageBox.Show("You can't enrol this course becouse you are young", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else if (Age > 30)
            {
                MessageBox.Show("You can't enrol this course becouse you are old", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            if (rbFemale.Checked == true)
            {
                gender = "Female";
            }
            else if (rbMale.Checked == true)
            {
                gender = "Male";
            }
            else
            {
                MessageBox.Show("You must choose Male or Female", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            string Cource="";



            string extra_click = "";

            if (clbCourses.SelectedIndex != -1)
            {
                Cource = clbCourses.SelectedItem.ToString();

                extra_click = "Yes";

                switch (Cource)
                {
                    case "C#":
                        lblOutput.Text = "Your Name is:" + Name + "\n" + "Your Age is:" + Age.ToString() + "\n" +
                             "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "Course is : " + Cource;
                
                break;
                    case "Java":
                        lblOutput.Text = "Your Name is:" + Name + "\n" + "Your Age is:" + Age.ToString() + "\n" +
                             "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "Course is : " + Cource;
                break;
                    case "HTML&CSS3":
                        lblOutput.Text = "Your Name is:" + Name + "\n" + "Your Age is:" + Age.ToString() + "\n" +
                             "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "Course is : " + Cource;
                
                break;
                    case "React":
                        lblOutput.Text = "Your Name is: " + Name + "\n" + "Your Age is: " + Age.ToString() + "\n" +
                            "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "Course is: " + Cource;
                
                break;



                }
            }
            else
            {
                MessageBox.Show("please choose at least one course.", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (extra.Checked)
            {
                extra_click = "yes";
                lblOutput.Text = "Your Name is: " + Name + "\n" + "Your Age is: " + Age.ToString() + "\n" +
                           "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "Course is: " + Cource + "\n" + "The Extra is:" + extra_click;
            }
            else
            {
               //no
            }
            txtName.Focus();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lblOutput.Text = "";
            rbMale.Checked = false;
            rbFemale.Checked = false;
            txtName.Text = "";
            txtID.Text = "";
            txtAge.Text = "";
            clbCourses.ClearSelected();
            extra.Checked = false;
        }
         
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

